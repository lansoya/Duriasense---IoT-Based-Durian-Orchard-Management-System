import 'dart:io';

import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

Future<void> exportToCsv(List<Map<String, String>> data) async {
  if (data.isEmpty) {
    print("⚠️ No data to export to CSV.");
    return;
  }

  List<List<String>> rows = [
    ['Timestamp', 'pH', 'Temperature', 'Moisture', 'EC'],
    ...data.map((item) => [
      item['timestamp'] ?? '',
      item['pH'] ?? '',
      item['Temperature'] ?? '',
      item['Moisture'] ?? '',
      item['EC'] ?? '',
    ])
  ];

  String csv = const ListToCsvConverter().convert(rows);

  final dir = await getApplicationDocumentsDirectory();
  final path = '${dir.path}/sensor_data.csv';
  final file = File(path);

  await file.writeAsString(csv);
  print("✅ CSV exported to: $path");
  Share.shareXFiles([XFile(path)], text: 'Here is the sensor_data.csv file');
}

Future<void> exportToPdf(List<Map<String, String>> data) async {
  if (data.isEmpty) {
    print("⚠️ No data to export to PDF.");
    return;
  }

  final pdf = pw.Document();

  pdf.addPage(
    pw.Page(
      build: (context) => pw.Table.fromTextArray(
        headers: ['Timestamp', 'pH', 'Temperature', 'Moisture', 'EC'],
        data: data.map((item) => [
          item['timestamp'] ?? '',
          item['pH'] ?? '',
          item['Temperature'] ?? '',
          item['Moisture'] ?? '',
          item['EC'] ?? '',
        ]).toList(),
      ),
    ),
  );

  await Printing.layoutPdf(onLayout: (format) => pdf.save());
}