import 'package:flutter/material.dart';

import 'history_details_page.dart'; // 🚀 ADD THIS
import 'sensor_database.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  List<Map<String, dynamic>> _sensorData = [];

  @override
  void initState() {
    super.initState();
    _loadSensorData();
  }

  Future<void> _loadSensorData() async {
    final data = await SensorDatabase.instance.fetchAllSensorData();
    setState(() {
      _sensorData = data;
    });
  }

  Future<void> _deleteSensorData(int id) async {
    await SensorDatabase.instance.deleteSensorData(id);
    _loadSensorData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("History")),
      body: _sensorData.isEmpty
          ? const Center(child: Text("No data yet"))
          : ListView.builder(
              itemCount: _sensorData.length,
              itemBuilder: (context, index) {
                final item = _sensorData[index];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: ListTile(
                    title: Text(
                      item['timestamp'],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 8),
                        Text("pH: ${item['ph']}"),
                        Text("Temperature: ${item['temperature']} °C"),
                        Text("Moisture: ${item['moisture']} %"),
                        Text("EC: ${item['ec']}"),
                        const SizedBox(height: 8),
                      ],
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deleteSensorData(item['id']),
                    ),
                    onTap: () {
                      // 🚀 Open HistoryDetailsPage
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HistoryDetailsPage(data: item),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
