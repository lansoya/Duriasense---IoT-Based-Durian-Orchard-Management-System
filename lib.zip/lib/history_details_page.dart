import 'package:flutter/material.dart';

class HistoryDetailsPage extends StatelessWidget {
  final Map<String, dynamic> data;

  const HistoryDetailsPage({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("History Details")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 16),
            Text(
              "📅 Timestamp: ${data['timestamp']}",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text("pH: ${data['ph']}", style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text("Temperature: ${data['temperature']} °C", style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text("Moisture: ${data['moisture']} %", style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text("EC: ${data['ec']}", style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 24),
            // OPTIONAL: You can add Export this Entry button here
            // ElevatedButton(
            //   onPressed: () {
            //     // TODO: Export single entry to CSV/PDF
            //   },
            //   child: const Text("Export this Entry"),
            // ),
          ],
        ),
      ),
    );
  }
}
