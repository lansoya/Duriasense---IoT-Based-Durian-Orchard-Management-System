import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class QRScannerPage extends StatefulWidget {
  const QRScannerPage({super.key});

  @override
  State<QRScannerPage> createState() => _QRScannerPageState();
}

class _QRScannerPageState extends State<QRScannerPage> {
  bool scanned = false;

  void _showResult(BuildContext context, String data) {
    final parts = data.split("|");
    String type = "-", location = "-", date = "-";

    for (var part in parts) {
      if (part.startsWith("Type:")) type = part.replaceFirst("Type:", "");
      if (part.startsWith("Location:")) location = part.replaceFirst("Location:", "");
      if (part.startsWith("Date:")) date = part.replaceFirst("Date:", "");
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("QR Code Scanned"),
        content: Text("Tree Type: $type\nLocation: $location\nDate Planted: $date"),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              setState(() => scanned = false); // Allow next scan
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan QR Code'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context), // Exit to bottom nav
        ),
      ),
      body: MobileScanner(
        onDetect: (BarcodeCapture capture) {
          if (scanned) return; // prevent multiple triggers
          final value = capture.barcodes.first.rawValue;
          if (value != null) {
            setState(() => scanned = true);
            _showResult(context, value);
          }
        },
      ),
    );
  }
}