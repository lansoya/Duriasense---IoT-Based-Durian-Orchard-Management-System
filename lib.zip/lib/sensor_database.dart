import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class SensorDatabase {
  static final SensorDatabase instance = SensorDatabase._init();

  static Database? _database;

  SensorDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('sensor_data.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
    CREATE TABLE sensor_data (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp TEXT,
      ph REAL,
      temperature REAL,
      moisture REAL,
      ec REAL
    )
    ''');
  }

  Future<void> insertSensorData({
    required String timestamp,
    required double ph,
    required double temperature,
    required double moisture,
    required double ec,
  }) async {
    final db = await instance.database;
    await db.insert('sensor_data', {
      'timestamp': timestamp,
      'ph': ph,
      'temperature': temperature,
      'moisture': moisture,
      'ec': ec,
    });
  }

  Future<List<Map<String, dynamic>>> fetchAllSensorData() async {
    final db = await instance.database;
    return await db.query('sensor_data', orderBy: 'timestamp DESC');
  }

  Future<void> deleteSensorData(int id) async {
    final db = await instance.database;
    await db.delete('sensor_data', where: 'id = ?', whereArgs: [id]);
  }
}
