import 'dart:async';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_reactive_ble/flutter_reactive_ble.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'export_helper.dart';
import 'history_page.dart';
import 'qr_page.dart';
import 'sensor_database.dart';
import 'splash_screen.dart'; // use splash screen

const Color durianGreen = Color(0xFF4CAF50);
void main() => runApp(const MyApp()); // RESTORED MyApp → dark mode works!

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isDarkMode = false;
  bool showSplash = true; // NEW - control Splash ONCE!

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => isDarkMode = prefs.getBool('darkMode') ?? false);
  }

  void _toggleTheme(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', value);
    setState(() => isDarkMode = value);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: showSplash
          ? SplashScreen(
              onFinish: () {
                setState(() {
                  showSplash = false; // After splash, show SensorApp!
                });
              },
            )
          : SensorApp(
              isDarkMode: isDarkMode,
              onThemeChanged: _toggleTheme,
            ),
    );
  }
}

final serviceUuid = Uuid.parse("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
final phChar = Uuid.parse("6E400002-B5A3-F393-E0A9-E50E24DCCA9E");
final tempChar = Uuid.parse("6E400003-B5A3-F393-E0A9-E50E24DCCA9E");
final moistChar = Uuid.parse("6E400004-B5A3-F393-E0A9-E50E24DCCA9E");
final ecChar = Uuid.parse("6E400005-B5A3-F393-E0A9-E50E24DCCA9E");

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

class SensorApp extends StatefulWidget {
  final bool isDarkMode;
  final Function(bool) onThemeChanged;
  const SensorApp({super.key, required this.isDarkMode, required this.onThemeChanged});

  @override
  State<SensorApp> createState() => _SensorAppState();
}

class _SensorAppState extends State<SensorApp> {
  final ble = FlutterReactiveBle();
  DiscoveredDevice? device;
  late QualifiedCharacteristic phQC, tempQC, moistQC, ecQC;
  late StreamSubscription<DiscoveredDevice> scanSub;

  String ph = "-", temp = "-", moist = "-", ec = "-";
  List<Map<String, String>> sensorLog = [];
  List<FlSpot> phData = [], tempData = [], moistData = [], ecData = [];
  int timeCounter = 0;
  int currentIndex = 0;

  bool alertedPH = false;
  bool alertedMoisture = false;

  @override
  void initState() {
    super.initState();

    // 🚀 FIRST → init notifications → to make sure plugin ready!
    _initNotifications();

    // THEN BLE
    _initBle();
  }

  Future<void> _initNotifications() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: android);
    await flutterLocalNotificationsPlugin.initialize(initSettings);
  }

  Future<void> _initBle() async {
  await Permission.bluetoothScan.request();
  await Permission.bluetoothConnect.request();
  await Permission.location.request();
  await Permission.notification.request();

  // 🚀 Start BLE scan with auto-retry
  await _startScan();
}

Future<void> _startScan() async {
  try {
    scanSub = ble.scanForDevices(withServices: []).listen((d) {
      if (d.name.isNotEmpty && d.name.contains("ESP32")) {
        print("Found device: ${d.name}");
        scanSub.cancel();
        setState(() => device = d);
        _connectToDevice(d);
      }
    }, onError: (e) {
      print("BLE Scan failed: $e");
      // 🚀 Retry after delay
      Future.delayed(const Duration(seconds: 3), () {
        print("Retrying BLE scan...");
        _startScan();
      });
    });
  } catch (e) {
    print("BLE scan exception: $e");
    // 🚀 Retry after delay
    Future.delayed(const Duration(seconds: 3), () {
      print("Retrying BLE scan...");
      _startScan();
    });
  }
}

Future<void> _connectToDevice(DiscoveredDevice d) async {
  ble.connectToDevice(id: d.id).listen((_) {}, onError: print);
  await ble.getDiscoveredServices(d.id);

  phQC = QualifiedCharacteristic(serviceId: serviceUuid, characteristicId: phChar, deviceId: d.id);
  tempQC = QualifiedCharacteristic(serviceId: serviceUuid, characteristicId: tempChar, deviceId: d.id);
  moistQC = QualifiedCharacteristic(serviceId: serviceUuid, characteristicId: moistChar, deviceId: d.id);
  ecQC = QualifiedCharacteristic(serviceId: serviceUuid, characteristicId: ecChar, deviceId: d.id);

  ble.subscribeToCharacteristic(phQC).listen((data) {
    final value = String.fromCharCodes(data);
    setState(() => ph = value);
    _logSensorData();
    _updateGraph(phData, value);
  });

  ble.subscribeToCharacteristic(tempQC).listen((data) {
    final value = String.fromCharCodes(data);
    setState(() => temp = value);
    _logSensorData();
    _updateGraph(tempData, value);
  });

  ble.subscribeToCharacteristic(moistQC).listen((data) {
    final value = String.fromCharCodes(data);
    setState(() => moist = value);
    _logSensorData();
    _updateGraph(moistData, value);
  });

  ble.subscribeToCharacteristic(ecQC).listen((data) {
    final value = String.fromCharCodes(data);
    setState(() => ec = value);
    _logSensorData();
    _updateGraph(ecData, value);
  });
}
  void _logSensorData() {
  final now = DateTime.now().toString();
  final record = {
    'timestamp': now,
    'pH': ph,
    'Temperature': temp,
    'Moisture': moist,
    'EC': ec
  };

  // 🚀 ALWAYS insert to SQLite → so user can see full history
  SensorDatabase.instance.insertSensorData(
    timestamp: now,
    ph: double.tryParse(ph) ?? 0.0,
    temperature: double.tryParse(temp) ?? 0.0,
    moisture: double.tryParse(moist) ?? 0.0,
    ec: double.tryParse(ec) ?? 0.0,
  );

  
  if (sensorLog.isEmpty || sensorLog.last.toString() != record.toString()) {
    sensorLog.add(record);
  }

  _checkSensorAlerts();
}

  void _checkSensorAlerts() {
    final phVal = double.tryParse(ph) ?? 7.0;
    final moistVal = double.tryParse(moist) ?? 50;

    if (phVal < 5.5 && !alertedPH) {
      _showNotification("Soil pH Alert", "Soil is acidic (pH: $ph)");
      alertedPH = true;
    } else if (phVal >= 5.5) {
      alertedPH = false;
    }

    if (moistVal < 59 && !alertedMoisture) {
      _showNotification("Moisture Alert", "Soil is dry (Moisture: $moist%)");
      alertedMoisture = true;
    } else if (moistVal >= 30) {
      alertedMoisture = false;
    }
  }

  Future<void> _showNotification(String title, String body) async {
    const androidDetails = AndroidNotificationDetails(
      'sensor_alerts', 'Sensor Alerts',
      importance: Importance.max,
      priority: Priority.high,
    );
    const platformDetails = NotificationDetails(android: androidDetails);
    await flutterLocalNotificationsPlugin.show(0, title, body, platformDetails);
  }

  String getPhRecommendation(String phStr) {
    final value = double.tryParse(phStr);
    if (value == null) return "-";
    if (value < 1.5) return "Recommend GML: 3.2kg";
    if (value < 2.5) return "Recommend GML: 2.4kg";
    if (value < 3.5) return "Recommend GML: 1.6kg";
    if (value < 4.5) return "Recommend GML: 800g";
    return "No GML needed";
  }

  String getMoistureRecommendation(String moistStr) {
    final value = double.tryParse(moistStr);
    if (value == null) return "-";
    if (value < 40) return "Moisture Critical – Water Now!";
    if (value < 50) return "Low Moisture – Moderate Watering Advised";
    if (value < 60) return "Slightly Dry – Watering Suggested Soon";
    return "Moisture Level Ideal – No Action Needed";
  }

  void _updateGraph(List<FlSpot> list, String val) {
    final parsed = double.tryParse(val);
    if (parsed != null) {
      setState(() {
        list.add(FlSpot(timeCounter.toDouble(), parsed));
        if (list.length > 20) list.removeAt(0);
        timeCounter++;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildDashboardPage(),
      _buildGraphsPage(),
      const QRPage(),
      const HistoryPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("DURIASENSE"),
        actions: [
          Switch(
            value: widget.isDarkMode,
            onChanged: widget.onThemeChanged,
            activeColor: Colors.yellow,
          ),
        ],
      ),
      body: pages[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (index) => setState(() => currentIndex = index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: durianGreen,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white70,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.sensors), label: "Dashboard"),
          BottomNavigationBarItem(icon: Icon(Icons.show_chart), label: "Graphs"),
          BottomNavigationBarItem(icon: Icon(Icons.qr_code), label: "QR"),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: "History"),
        ],
      ),
    );
  }

  Widget _buildDashboardPage() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              Icon(
                device != null ? Icons.bluetooth_connected : Icons.bluetooth_disabled,
                color: device != null ? Colors.green : Colors.red,
              ),
              const SizedBox(width: 10),
              Text(device != null ? "Connected to ${device!.name}" : "Not connected"),
            ],
          ),
          const SizedBox(height: 16),
          _buildSensorCard("pH Level", ph, getPhRecommendation(ph), Icons.science),
          _buildSensorCard("Temperature", "$temp °C", "", Icons.thermostat),
          _buildSensorCard("Moisture", "$moist %", getMoistureRecommendation(moist), Icons.water_drop),
          _buildSensorCard("EC Level", ec, "", Icons.bolt),
          const Spacer(),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => exportToCsv(sensorLog),
                  icon: const Icon(Icons.file_copy),
                  label: const Text("Export CSV"),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () => exportToPdf(sensorLog),
                  icon: const Icon(Icons.picture_as_pdf),
                  label: const Text("Export PDF"),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSensorCard(String label, String value, String subtitle, IconData icon) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.only(bottom: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 32, color: Colors.teal),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  if (subtitle.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        subtitle,
                        style: TextStyle(fontSize: 14, color: Colors.grey.shade700),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  Widget _buildGraphsPage() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text("pH", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 200, child: _buildChart(phData, Colors.teal)),
        const SizedBox(height: 8),
        _buildGradientBar("pH", double.tryParse(ph) ?? 7.0, 0.0, 9.0),
        const SizedBox(height: 16),

        const Text("Temperature (°C)", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 200, child: _buildChart(tempData, Colors.redAccent)),
        const SizedBox(height: 8),
        _buildGradientBar("Temperature", double.tryParse(temp) ?? 25.0, -40.0, 80.0),
        const SizedBox(height: 16),

        const Text("Moisture (%)", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 200, child: _buildChart(moistData, Colors.blue)),
        const SizedBox(height: 8),
        _buildGradientBar("Moisture", double.tryParse(moist) ?? 50.0, 0.0, 100.0),
        const SizedBox(height: 16),

        const Text("EC", style: TextStyle(fontWeight: FontWeight.bold)),
        SizedBox(height: 200, child: _buildChart(ecData, Colors.purple)),
        const SizedBox(height: 8),
        _buildGradientBar("EC", double.tryParse(ec) ?? 1.0, 0.0, 20000.0),
      ],
    );
  }

  Widget _buildChart(List<FlSpot> spots, Color color) {
    return LineChart(
      LineChartData(
        minY: 0,
        titlesData: FlTitlesData(show: false),
        gridData: FlGridData(show: false),
        borderData: FlBorderData(show: true),
        lineBarsData: [
          LineChartBarData(
            spots: spots,
            isCurved: true,
            color: color,
            belowBarData: BarAreaData(show: false),
            dotData: FlDotData(show: false),
          )
        ],
      ),
    );
  }

  Widget _buildGradientBar(String label, double value, double min, double max) {
    double normalized = ((value - min) / (max - min)).clamp(0.0, 1.0);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Stack(
          children: [
            Container(
              height: 20,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                gradient: const LinearGradient(
                  colors: [
                    Colors.red,
                    Colors.orange,
                    Colors.yellow,
                    Colors.lightGreen,
                    Colors.green
                  ],
                ),
              ),
            ),
            Positioned(
              left: normalized * MediaQuery.of(context).size.width * 0.82,
              child: const Icon(Icons.arrow_drop_up, color: Colors.black, size: 28),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text("$label: ${value.toStringAsFixed(2)}"), // ADD VALUE TEXT (like you wanted!)
      ],
    );
  }
}
